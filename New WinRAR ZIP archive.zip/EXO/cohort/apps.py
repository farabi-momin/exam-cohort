from django.apps import AppConfig


class CohortConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cohort'
