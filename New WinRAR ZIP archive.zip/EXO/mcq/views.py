from django.shortcuts import render
from .forms import questionForm
from .models import questionModel

# Create your views here.
      
